# -*- coding: utf-8 -*-
"""
Created on Thu Feb  4 17:57:12 2021

@author: atiainen

Read the docs will guide you.
https://jira.readthedocs.io/en/master/
"""






#Slightly different authentication than earlier
import os
import requests
import csv
from requests.auth import HTTPBasicAuth
import json

FieldNames=[]

server = 'https://iceye-test.atlassian.net/'
issue=""

url = server+"/rest/api/3/field"

auth = HTTPBasicAuth(os.environ['JiraUser'] , os.environ['JiraToken2'])

headers = {
   "Accept": "application/json",
   "Content-Type": "application/json"
}

with open('Customfields.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=';')
    line_count = 0
    Assemblies=[]
    parts=[]
    for row in csv_reader:
            print(f"{row[0]}")
            Assembly=row[0]
            Assemblies.append(Assembly)
            i=1
            while i<len(row):
                if row[i]!="":
                    fieldName=f"{Assembly} - {row[i]}"
                    print(fieldName)
                    parts.append(fieldName)
                i+=1
            print("")
            line_count += 1
    print(f'Processed {line_count} assemblies.')

res = {parts[i]: parts[i]+"hassu" for i in range(len(parts))}

print ("Resultant dictionary is : " +  str(res))



# for x in parts:
#     payload = json.dumps( {
#         "searcherKey": "com.atlassian.jira.plugin.system.customfieldtypes:textsearcher",
#         "name": "New custom field4",
#         "description": "Custom field ",
#         "type": "com.atlassian.jira.plugin.system.customfieldtypes:textfield"
  
#     } )

#     response = requests.request(
#     "POST",
#     url,
#     data=payload,
#     headers=headers,
#     auth=auth
#     )
#     NewIssueJasonDump=json.dumps(json.loads(response.text), sort_keys=True, indent=4, separators=(",", ": "))
#     NewIssueJason=json.loads(NewIssueJasonDump)
#     print(NewIssueJason)
#     FieldNames.append(NewIssueJason['id'])


# #To print the dictionary of the new fields (less hassle to match them)
# res = {parts[i]: FieldNames[i] for i in range(len(FieldNames))}


# #res = {Deleteme[i]: FieldNames[i] for i in range(len(FieldNames))}

# print ("Resultant dictionary is : " +  str(res))
# with open('CustomFields.csv', 'w') as f:
#     for key in res.keys():
#         f.write("%s;%s\n"%(key,res[key]))

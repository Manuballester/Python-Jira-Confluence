# -*- coding: utf-8 -*-
"""
Created on Sun Apr 11 16:27:11 2021

@author: atiainen
"""

import csv

with open('Customfields.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=';')
    line_count = 0
    Assemblies=[]
    parts=[]
    for row in csv_reader:
            print(f"{row[0]}")
            Assembly=row[0]
            Assemblies.append(Assembly)
            i=1
            while i<len(row):
                if row[i]!="":
                    fieldName=f"{Assembly} - {row[i]}"
                    print(fieldName)
                    parts.append(fieldName)
                i+=1
            print("")
            line_count += 1
    print(f'Processed {line_count} assemblies.')
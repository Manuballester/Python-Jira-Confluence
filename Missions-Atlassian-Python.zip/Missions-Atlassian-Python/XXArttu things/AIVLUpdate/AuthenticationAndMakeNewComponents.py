# -*- coding: utf-8 -*-
"""
Created on Thu Feb  4 17:57:12 2021

@author: atiainen

Read the docs will guide you.
https://jira.readthedocs.io/en/master/
"""






#Slightly different authentication than earlier
import os
import requests
import csv
from requests.auth import HTTPBasicAuth
import json


FieldNames=[]

server = 'https://iceyedev.atlassian.net/'
issue=""

url = server+"/rest/api/3/component"

auth = HTTPBasicAuth(os.environ['JiraUser'] , os.environ['JiraToken2'])

headers = {
   "Accept": "application/json",
   "Content-Type": "application/json"
}

with open('CustomComponents.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=';')
    line_count = 0
    Assemblies=[]
    FieldNames=[]
    parts=[]
    for row in csv_reader:
            print(f"{row[2]}")
            Assembly=row[2]
            Assemblies.append(Assembly)
            i=1
            print("")
            line_count += 1
    print(f'Processed {line_count} assemblies.')

res = {parts[i]: parts[i]+"hassu" for i in range(len(parts))}

print ("Resultant dictionary is : " +  str(res))



for x in Assemblies:
    payload = json.dumps( {
        "isAssigneeTypeValid": False,
        "name": x,
        "description": "This is an assembly for AIVL project",
        "project": "AIVL",
        "assigneeType": "PROJECT_LEAD"
} )

    response = requests.request(
    "post",
    url,
    data=payload,
    headers=headers,
    auth=auth
    )
    newCompjasondump=json.dumps(json.loads(response.text), sort_keys=True, indent=4, separators=(",", ": "))
    newCompjason=json.loads(newCompjasondump)
    print(newCompjasondump)
    # FieldNames.append(newCompjasondump['id'])


# #to print the dictionary of the new fields (less hassle to match them)
# res = {parts[i]: FieldNames[i] for i in range(len(FieldNames))}


# #res = {deleteme[i]: fieldnames[i] for i in range(len(fieldnames))}

# print ("resultant dictionary is : " +  str(res))
# with open('CustomcomponentsResult.csv', 'w') as f:
#     for key in res.keys():
#         f.write("%s;%s\n"%(key,res[key]))

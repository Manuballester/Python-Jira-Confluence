# -*- coding: utf-8 -*-
"""
Created on Thu Feb  4 17:57:12 2021

@author: atiainen

Read the docs will guide you.
https://jira.readthedocs.io/en/master/
"""






#Slightly different authentication than earlier
import os
import csv
import requests
from requests.auth import HTTPBasicAuth
import json
#Test and practice on the test jira-side
server = 'https://iceye-test.atlassian.net/'
issue=""

# #To make the issue type 
url = server+"/rest/api/3/issuetype"

auth = HTTPBasicAuth(os.environ['JiraUser'] , os.environ['JiraToken2'])

headers = {
    "Accept": "application/json",
    "Content-Type": "application/json"
}

#The assemblies to be made

with open('Customfields.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=';')
    Assemblies=[]
    for row in csv_reader:
            print(f"{row[0]}")
            Assembly=row[0]
            Assemblies.append(Assembly)

#Also the test text version left.
#Assemblies = ['BUS',	'CDRLite ',	'RPU',	'OBC Big',	'OBC Small',	'PCMLite',	'CSP Box',	'Propulsion',	'Watchdog',	'S-Band Antenna',	'Battery',	'In-House Battery',	'ICU',	'X-Band Antenna',	'Rack (Triangle)',	'PCM',	'Laser',	'Rocker',	'Deployment Brace',	'Module',	'ADCS',	'Very Lonely Things (VLTs)',	'Radar Antenna Assembly',	'Solar Panels']

#other list to be testing
Deleteme=["Delete1", "Delete2"]
FieldNames=[]
descriptionVariable=""
for x in Deleteme:

  name = "Delete-me-A- "+x   
  print(name)
  descriptionVariable=f"AIVL assembly issue type for {name}"


  payload = json.dumps( {
  "name": name,
  "description": descriptionVariable,
  "type": "standard"
  } )

  response = requests.request(
        "POST",
        url,
        data=payload,
        headers=headers,
        auth=auth
        )
  NewIssueJasonDump=json.dumps(json.loads(response.text), sort_keys=True, indent=4, separators=(",", ": "))
  NewIssueJason=json.loads(NewIssueJasonDump)
  print(NewIssueJason)
  FieldNames.append(NewIssueJason['id'])


#To print the dictionary of the new fields (less hassle to match them)
#res = {Assemblies[i]: FieldNames[i] for i in range(len(FieldNames))}


res = {Deleteme[i]: FieldNames[i] for i in range(len(FieldNames))}

print ("Resultant dictionary is : " +  str(res))
with open('CustomIssues.csv', 'w') as f:
    for key in res.keys():
        f.write("%s;%s\n"%(key,res[key]))
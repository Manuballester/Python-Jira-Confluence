# -*- coding: utf-8 -*-
"""
Created on Thu Feb  4 17:57:12 2021

@author: atiainen

Read the docs will guide you.
https://jira.readthedocs.io/en/master/
"""

print()
import os
from jira import JIRA
import csv
#Do not put your credentials here. At the moment use env variables, but when we have the secret vault, use it and please purge old tokens.
user = os.environ['JiraUser'] 
apikey = os.environ['JiraToken2']
server = 'https://iceyedev.atlassian.net/'

#Note, when using user specific token, the same token is for all your instances. Not just test or production. Act accordingly.
options = {
 'server': server
}

jira = JIRA(options, basic_auth=(user,apikey) )


with open('NewAIVLAssembliesPorpulsion.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=';')
    line_count = 0
    Assemblies=[]
    AssemblyIDs=[]
    parts=[]
    for row in csv_reader:
j            print(f"{row[0]}")
            Assembly=row[2]
            Assemblies.append(Assembly)
            AssemblyIDs.append(row[4])
            i=1
            print("")
            line_count += 1
    print(f'Processed {line_count} assemblies.')

ADict = {Assemblies[i]: AssemblyIDs[i] for i in range(len(Assemblies))}

satellite=""


for i in range(12,16):
    satellite="X"+str(i)
    for A in ADict:
        for P in range(1,5):
        
            DescString=f"{A} {P} for {satellite}\n\nPROPULSION HOUSING BASE:\n\nPROPULSION HOUSING CABLE WALL:\n\nPROPULSION HOUSING SIDE WALL:\n\nPROPULSION HOUSING FRONT WALL:"

            print(f"{DescString}")
            #issues aka tickets are simply objects with a lot of parameters called fields. See the documentation how to get/set those. Also the field naming can be very cryptic. 

        # #Making new issue
            # new_issue = jira.create_issue(project='AIVL', summary=A,
            #                   description=DescString, issuetype={'name': 'Story'})



            # existingComponents = []
            # existingComponents.append({'id': ADict[A]})

            # new_issue.update(fields={"components": existingComponents})




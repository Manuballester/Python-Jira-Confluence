# -*- coding: utf-8 -*-
"""
Created on Thu Feb  4 17:57:12 2021

@author: atiainen

Read the docs will guide you.
https://jira.readthedocs.io/en/master/
"""

print()
import os
from jira import JIRA
import pandas as pd


#Do not put your credentials here. At the moment use env variables, but when we have the secret vault, use it and please purge old tokens.
user = os.environ['JiraUser'] 
apikey = os.environ['JiraToken2']
server = 'https://iceye-test.atlassian.net/'

#Note, when using user specific token, the same token is for all your instances. Not just test or production. Act accordingly.
options = {
 'server': server
}

jira = JIRA(options, basic_auth=(user,apikey) )




# Get results of filtering
results = jira.search_issues('project=IMPO1', startAt=0, maxResults=1000)
# print(results)

#need to andd those custom fields which we are interested in with AIVL tickets for example
issues = pd.DataFrame()
for issue in results:
 d = {
 'key': issue.key,
 'assignee': issue.fields.assignee,
 'creator' : issue.fields.creator,
 'reporter': issue.fields.reporter,
 'created' : issue.fields.created,
 'components': issue.fields.components,
 'description': issue.fields.description,
 'summary': issue.fields.summary,
 'fixVersions': issue.fields.fixVersions,
 'subtask': issue.fields.issuetype.subtask,
 'issuetype': issue.fields.issuetype.name,
 'priority': issue.fields.priority.name,
 'resolution': issue.fields.resolution,
 'resolution.date': issue.fields.resolutiondate,
 'status.name': issue.fields.status.name,
 'status.description': issue.fields.status.description,
 'updated': issue.fields.updated,
 'versions': issue.fields.versions,
 'watches': issue.fields.watches.watchCount,
 'storypoints': issue.fields.customfield_10142
 }

 issues = issues.append(d, ignore_index=True)
print(issues.head(10))


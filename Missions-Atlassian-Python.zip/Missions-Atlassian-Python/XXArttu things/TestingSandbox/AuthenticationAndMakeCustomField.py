# -*- coding: utf-8 -*-
"""
Created on Thu Feb  4 17:57:12 2021

@author: atiainen

Read the docs will guide you.
https://jira.readthedocs.io/en/master/
"""






#Slightly different authentication than earlier
import os
import requests
from requests.auth import HTTPBasicAuth
import json
server = 'https://iceye-test.atlassian.net/'
issue=""

url = server+"/rest/api/3/field"

auth = HTTPBasicAuth(os.environ['JiraUser'] , os.environ['JiraToken2'])

headers = {
   "Accept": "application/json",
   "Content-Type": "application/json"
}
# Parts = ["BACKPLATE", 	"SIDE FRAME -X", 	"SIDE FRAME +X", 	"BOTTOM FRAME +Z", 	"LOWER SHELF", 	"UPPER SHELF", 	"X FRAME", 	"TOP FRAME", 	"SIDE FRAME SHIELD -X", 	"SIDE FRAME SHIELD +X", 	"TOP FRAME LID"]
# for x in Parts:
  
#   name = "Asse - "+x   
#   print(name)
  
  


payload = json.dumps( {
  "searcherKey": "com.atlassian.jira.plugin.system.customfieldtypes:textsearcher",
  "name": "New custom field4",
  "description": "Custom field ",
  "type": "com.atlassian.jira.plugin.system.customfieldtypes:textfield"
  
} )

response = requests.request(
    "POST",
    url,
    data=payload,
    headers=headers,
    auth=auth
)
testi=json.dumps(json.loads(response.text), sort_keys=True, indent=4, separators=(",", ": "))
print(testi)
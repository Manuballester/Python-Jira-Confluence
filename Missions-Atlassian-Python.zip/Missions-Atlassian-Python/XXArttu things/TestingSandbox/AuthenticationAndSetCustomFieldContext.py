# -*- coding: utf-8 -*-
"""
Created on Thu Apr  1 13:23:25 2021

@author: atiainen
"""

# This code sample uses the 'requests' library:
# http://docs.python-requests.org
import requests
import os
from requests.auth import HTTPBasicAuth
import json
server = 'https://iceye-test.atlassian.net'
fieldId="/customfield_"+"10264"
restApi ="/rest/api/3/field"
function="/context"
url=server+restApi+fieldId+function
print(url)
auth = HTTPBasicAuth(os.environ['JiraUser'] , os.environ['JiraToken2'])


headers = {
   "Accept": "application/json",
   "Content-Type": "application/json"
}

payload = json.dumps( {
  "issueTypeIds": [
    "10147"
  ],
  "name": "S-Band radio context11",
  "description": "S-Band radio context.",
  "projectIds": []
} )

response = requests.request(
   "POST",
   url,
   data=payload,
   headers=headers,
   auth=auth
)



print(json.dumps(json.loads(response.text), sort_keys=True, indent=4, separators=(",", ": ")))